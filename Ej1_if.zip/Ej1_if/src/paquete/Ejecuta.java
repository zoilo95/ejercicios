package paquete;

public class Ejecuta {

	public static void main(String[] args) {
		
		String pais = "Espa�a";
		boolean historia=false;
		
		if( (pais.equals("Espa�a") || pais.equals("Francia")) && historia==true) {
			System.out.println("Encontrado");
		}
		
		if( pais.equals("Espa�a") || pais.equals("Francia") && historia==true) {
			System.out.println("Encontrado si");
		}

		
		/*
		 El alumno aprueba si supera la nota del examen o entrega las 2 pr�cticas.
		 */
		
		
		/*float nota;
		boolean practica1Entregada;
		boolean practica2Entregada;
		
		nota = 10;
		practica1Entregada = true;
		practica2Entregada = false;
		
		if((practica1Entregada==true && practica2Entregada==true) || nota>=5 ) {
			System.out.println("Aprobado");
		}else {
			System.out.println("Suspenso");
		}*/
		
	}
	
	

}
